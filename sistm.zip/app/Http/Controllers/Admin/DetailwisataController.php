<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Detailwisata; // Mengganti dengan model Detailwisata

class DetailwisataController extends Controller
{
    public function indexPage(Request $request)
    {
        // Mengambil data dari model Detailwisata
        $detailWisata = Detailwisata::get();
        $search = $request->input('search');
        $detailWisata = Detailwisata::when($search, function ($query, $search) {
            return $query->where('nama_tempat', 'like', "%$search%")
                         ->orWhere('rating', 'like', "%$search%")
                         ->orWhere('jumlah_ulasan', 'like', "%$search%");
        })->paginate(10);
        return view('admin.pages.detailwisata.index', compact('detailWisata'));
    }

    function tambah() {
        // return view('admin.pages.detailwisata.tambah');
    }

    function submit(Request $request) {
        $detailWisata = new Detailwisata();
        $detailWisata->nama_tempat = $request->nama_tempat;
        $detailWisata->rating = $request->rating;
        $detailWisata->jumlah_ulasan = $request->jumlah_ulasan;
        $detailWisata->foto_url = $request->foto_url;
        $detailWisata->deskripsi = $request->deskripsi;
        $detailWisata->save();

        return redirect()->route('detailwisata.index')->with('success', 'Data detail wisata berhasil ditambahkan.');
    }

    function edit($id) {
        $detailWisata = Detailwisata::find($id);
        return view('admin.pages.detailwisata.edit', compact('detailWisata'));
    }

    function update(Request $request, $id) {
        $detailWisata = Detailwisata::findOrFail($id);
        $detailWisata->nama_tempat = $request->nama_tempat;
        $detailWisata->rating = $request->rating;
        $detailWisata->jumlah_ulasan = $request->jumlah_ulasan;
        $detailWisata->foto_url = $request->foto_url;
        $detailWisata->deskripsi = $request->deskripsi;
        $detailWisata->save();

        return redirect()->route('detailwisata.index')->with('success', 'Data detail wisata berhasil diedit.');
    }

    function delete($id) {
        $detailWisata = Detailwisata::find($id);
        $detailWisata->delete();
        return redirect()->route('detailwisata.index')->with('success', 'Data detail wisata berhasil dihapus.');
    }
}
