
<?php $__env->startSection('title','Wisata'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Wisata</h1>

<div class="d-flex justify-content-between flex-wrap align-items-center mb-2">
    <h4 class="mb-2">List Wisata</h4>
    
    <!-- Kolom Cari -->
    <form action="<?php echo e(route('wisata.index')); ?>" method="GET" class="d-flex mb-0">
        <div class="input-group">
            <input type="text" name="search" class="form-control bg-light border-0 small"
                   placeholder="Cari wisata..." aria-label="Search" aria-describedby="basic-addon2"
                   value="<?php echo e(request('search')); ?>">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search fa-sm"></i>
                </button>
            </div>
        </div>
    </form>

    <a class="btn btn-success ms-auto mb-2" href="<?php echo e(route('wisata.tambah')); ?>">Tambah</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="table-responsive">
    <table class="table table-bordered">
        <thead class="thead-light">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jenis Wisata</th>
                <th>Fasilitas Wisata</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration + ($wisata->currentPage() - 1) * $wisata->perPage()); ?></td>
                <td><?php echo e($data->nama); ?></td>
                <td><?php echo e($data->jenis_wisata); ?></td>
                <td><?php echo e($data->fasilitas_wisata); ?></td>
                <td><?php echo e($data->latitude); ?></td>
                <td><?php echo e($data->longitude); ?></td>
                <td class="d-flex gap-2">
                    <a href="<?php echo e(route('wisata.edit', $data->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('wisata.delete', $data->id)); ?>" method="post" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center">Data tidak ditemukan</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Menambahkan Pagination Links -->
<div class="d-flex justify-content-center mt-3">
    <nav aria-label="Page navigation" class="w-100">
        <?php echo e($wisata->onEachSide(2)->links('pagination::bootstrap-4')); ?>

    </nav>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\skripsi\resources\views/admin/pages/wisata/index.blade.php ENDPATH**/ ?>