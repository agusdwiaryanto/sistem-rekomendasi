
<?php $__env->startSection('title','Edit'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Edit</h1>

<form action="<?php echo e(route('wisata.update', $wisata->id)); ?>" method="post">
    <?php echo csrf_field(); ?>

    <label>Nama Wisata</label>
    <input type="text" name="nama" value="<?php echo e($wisata->nama); ?>" class="form-control mb-2">

    <label>Jenis Wisata</label>
    <div class="mb-2">
        <?php
            $jenisWisataSelected = explode(',', $wisata->jenis_wisata); // Konversi string ke array
        ?>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Alam" <?php echo e(in_array('Wisata Alam', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Alam</label><br>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Sejarah" <?php echo e(in_array('Wisata Sejarah', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Sejarah</label><br>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Budaya" <?php echo e(in_array('Wisata Budaya', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Budaya</label>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Kuliner" <?php echo e(in_array('Wisata Kuliner', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Kuliner</label><br>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Edukasi" <?php echo e(in_array('Wisata Edukasi', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Edukasi</label><br>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Religi" <?php echo e(in_array('Wisata Religi', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Religi</label>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Air" <?php echo e(in_array('Wisata Air', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Air</label><br>
        <label><input type="checkbox" name="jenis_wisata[]" value="Wisata Rekrasi" <?php echo e(in_array('Wisata Rekrasi', $jenisWisataSelected) ? 'checked' : ''); ?>> Wisata Rekrasi</label>
    </div>

    <label>Fasilitas Wisata</label>
    <div class="mb-2">
        <?php
            $fasilitasWisataSelected = explode(',', $wisata->fasilitas_wisata); // Konversi string ke array
        ?>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Tempat Parkir" <?php echo e(in_array('Tempat Parkir', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Tempat Parkir</label><br>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Restoran" <?php echo e(in_array('Restoran', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Restoran</label><br>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Kamping" <?php echo e(in_array('Kamping', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Kamping</label>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Outbond" <?php echo e(in_array('Outbond', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Outbond</label><br>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Pemandu" <?php echo e(in_array('Pemandu', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Pemandu</label><br>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Toilet" <?php echo e(in_array('Toilet', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Toilet</label>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Mushola" <?php echo e(in_array('Mushola', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Mushola</label><br>
        <label><input type="checkbox" name="fasilitas_wisata[]" value="Tempat Bermain" <?php echo e(in_array('Tempat Bermain', $fasilitasWisataSelected) ? 'checked' : ''); ?>> Tempat Bermain</label><br>
    </div>

    <label>Latitude</label>
    <input type="number" step="any" name="latitude" value="<?php echo e($wisata->latitude); ?>" class="form-control mb-2">

    <label>Longitude</label>
    <input type="number" step="any" name="longitude" value="<?php echo e($wisata->longitude); ?>" class="form-control mb-2">

    <button class="btn btn-primary">Edit Wisata</button>
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\skripsi\resources\views/admin/pages/wisata/edit.blade.php ENDPATH**/ ?>